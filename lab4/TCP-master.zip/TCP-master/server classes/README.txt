*******************************************************
-------------------	ECE361 SERVER ---------------------
*******************************************************

- to run the server simply type:
>>java MainClass [port number] [servic type] [mode]

Service type can be: {ECHO_SERVER, FTP_SERVER,ARQ_SERVER,CC_SERVER,ROUTING_SERVE
R,PROJECT_SERVER}

Mode can be: {VERBOSE,SILENT,LOG,LOGVERBOSE}

The default port number is 9876
The default Service depends on the current lab session
The default Mode is VERBOSE